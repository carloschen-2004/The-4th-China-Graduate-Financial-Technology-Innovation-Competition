README v3_plus
This package adds recommend_user_profiles.py to v3, which generates recommended user profiles for all products and maps new products (new_flag=1) to the most similar existing product.

Usage:
  python recommend_user_profiles.py --data_dir data --model_dir outputs --out_csv outputs/recommended_user_profiles.csv --k 200
