import os, argparse, time
import pandas as pd, numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from models.user_tower import UserTower
from models.product_tower import ProductTower
from models.dual_tower import DualTowerContrastive
from utils.data_cleaner_v3 import auto_clean_data_v3
from utils.feature_align import align_product_features, save_aligned
from utils.preprocess import preprocess_users
from tqdm import tqdm

LOG_PATH = 'outputs/train_log.txt'
def log(s):
    print(s)
    with open(LOG_PATH, 'a', encoding='utf-8') as f:
        f.write(str(s)+'\n')

class CategoryDataset(Dataset):
    def __init__(self, merged_df, user_cols, prod_cols):
        self.merged = merged_df.reset_index(drop=True)
        self.user_cols = user_cols
        self.prod_cols = prod_cols
        if len(self.prod_cols) == 0:
            self.merged['prod_hash'] = self.merged['prod_id'].astype(str).apply(lambda x: hash(x)%1000)
            self.prod_cols = ['prod_hash']

    def __len__(self):
        return len(self.merged)
    def __getitem__(self, idx):
        row = self.merged.iloc[idx]
        u = row[self.user_cols].values.astype(float)
        p = row[self.prod_cols].values.astype(float) if len(self.prod_cols)>0 else np.array([0.0])
        return u, p

def collate_fn(batch):
    users = np.stack([b[0] for b in batch])
    prods = np.stack([b[1] for b in batch])
    import torch
    users = torch.tensor(users, dtype=torch.float32)
    prods = torch.tensor(prods, dtype=torch.float32)
    return users, prods

def train_for_category(cat, args, cust_df, prod_aligned, events_df):
    start = time.time()
    log(f"[TRAIN] Starting category {cat}")
    sub = prod_aligned.get(cat)
    if sub is None:
        log(f"[TRAIN] No aligned product data for {cat}"); return
    prod_sub = sub['df'].reset_index(drop=True)
    prod_cols = sub['numeric_cols']
    ev = events_df[events_df['event_type'].isin(['A','B'])].copy()
    ev = ev[ev['prod_id'].astype(str).isin(prod_sub['prod_id'].astype(str))]
    if ev.shape[0] == 0:
        log(f"[TRAIN] No successful events for {cat}"); return
    merged = ev.merge(cust_df, on='cust_no', how='inner').merge(prod_sub, on='prod_id', how='inner')
    if merged.shape[0] == 0:
        log(f"[TRAIN] Merged empty for {cat}"); return
    user_cols = ['gender','age','edu_bg','marriage_situ_cd']
    ds = CategoryDataset(merged, user_cols, prod_cols)
    if len(ds) < max(16, args.batch_size):
        log(f"[TRAIN] Too few samples ({len(ds)}) for {cat}; skipping."); return
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, collate_fn=collate_fn, drop_last=True)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    user_dim = len(user_cols)
    prod_dim = len(prod_cols) if len(prod_cols)>0 else 1
    user_t = UserTower(user_dim, embed_dim=args.embed_dim).to(device)
    prod_t = ProductTower(prod_dim, embed_dim=args.embed_dim).to(device)
    model = DualTowerContrastive(user_t, prod_t, temperature=args.temperature, eps=1e-8).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    for epoch in range(args.epochs):
        model.train()
        total_loss = 0.0
        iters = 0
        for users, prods in tqdm(loader, desc=f"{cat} epoch {epoch+1}"):
            users = users.to(device); prods = prods.to(device)
            optimizer.zero_grad()
            loss = model(users, prods)
            if not torch.is_tensor(loss):
                loss = torch.tensor(float(loss), requires_grad=True, device=device)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            total_loss += float(loss.detach().cpu().numpy())
            iters += 1
        avg_loss = total_loss / max(iters,1)
        log(f"{cat} epoch {epoch+1} avg loss: {avg_loss:.6f}")
    save_path = os.path.join(args.save_dir, f'model_{cat}.pth')
    os.makedirs(args.save_dir, exist_ok=True)
    torch.save({
        'user_state': user_t.state_dict(),
        'prod_state': prod_t.state_dict(),
        'prod_cols': prod_cols,
        'prod_dim': prod_dim,
        'user_cols': user_cols
    }, save_path)
    log(f"[TRAIN] Saved {save_path} time_elapsed={(time.time()-start):.1f}s")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', default='data')
    parser.add_argument('--save_dir', default='outputs')
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--batch_size', type=int, default=256)
    parser.add_argument('--lr', type=float, default=3e-4)
    parser.add_argument('--embed_dim', type=int, default=64)
    parser.add_argument('--temperature', type=float, default=1.0)
    args = parser.parse_args()
    if os.path.exists(LOG_PATH):
        os.remove(LOG_PATH)
    cleaned = auto_clean_data_v3(args.data_dir)
    cust_df = cleaned.get('cust_dataset.csv') if cleaned.get('cust_dataset.csv') is not None else pd.read_csv(os.path.join(args.data_dir,'cust_dataset.csv'))
    events_df = cleaned.get('event_dataset.csv') if cleaned.get('event_dataset.csv') is not None else pd.read_csv(os.path.join(args.data_dir,'event_dataset.csv'))
    prod_df = cleaned.get('product_xlsx') if cleaned.get('product_xlsx') is not None else pd.read_excel(os.path.join(args.data_dir,'productLabels_multiSpreadsheets.xlsx'), sheet_name=None)
    if isinstance(prod_df, dict):
        prod_df = pd.concat(list(prod_df.values()), ignore_index=True, sort=False)
    aligned = align_product_features(prod_df, min_numeric_cols=6)
    save_aligned(args.data_dir, aligned)
    cust_df = preprocess_users(cust_df)
    os.makedirs(os.path.join(args.data_dir,'aligned'), exist_ok=True)
    cust_df.to_csv(os.path.join(args.data_dir,'aligned','aligned_cust_dataset.csv'), index=False)
    cats = list(aligned.keys())
    for c in cats:
        train_for_category(c, args, cust_df, aligned, events_df)
