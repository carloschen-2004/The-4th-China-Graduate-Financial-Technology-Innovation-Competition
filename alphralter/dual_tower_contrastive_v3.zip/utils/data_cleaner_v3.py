import os, sys
import pandas as pd
import numpy as np

def is_numeric_like(series, pct_thresh=0.7):
    s = series.dropna().astype(str)
    if len(s)==0:
        return False
    numeric_cnt = s.str.match(r'^[-+]?\d*\.?\d+$').sum()
    return (numeric_cnt / len(s)) >= pct_thresh

def clean_df_smart(df, name=None, force_fill_zero=False):
    empty_cols = [c for c in df.columns if df[c].isna().all()]
    if empty_cols:
        df = df.drop(columns=empty_cols)
    df = df.replace(r'^\s*$', pd.NA, regex=True)
    for col in df.columns:
        try:
            if is_numeric_like(df[col]):
                df[col] = pd.to_numeric(df[col], errors='coerce')
        except Exception:
            pass
    for col in df.columns:
        if df[col].dtype == object or df[col].dtype.name=='category':
            if col.lower() in ['cust_no', 'prod_id']:
                continue
            if df[col].nunique() < 200:
                df[col] = pd.factorize(df[col].astype(str))[0]
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            if force_fill_zero or df[col].isna().sum()>0:
                df[col] = df[col].fillna(0)
        else:
            df[col] = df[col].fillna(0)
    return df

def auto_clean_data_v3(data_dir, save=True):
    cleaned_dir = os.path.join(data_dir, 'cleaned')
    os.makedirs(cleaned_dir, exist_ok=True)
    results = {}
    for fn in ['cust_dataset.csv', 'event_dataset.csv']:
        p = os.path.join(data_dir, fn)
        if not os.path.exists(p):
            print(f'[CLEAN] Missing {fn}; skipping.')
            continue
        df = pd.read_csv(p, dtype=object)
        df = clean_df_smart(df, name=fn)
        if 'cust_no' in df.columns:
            df['cust_no'] = df['cust_no'].astype(str)
        if 'prod_id' in df.columns:
            df['prod_id'] = df['prod_id'].astype(str)
        outp = os.path.join(cleaned_dir, 'cleaned_' + fn)
        if save:
            df.to_csv(outp, index=False)
        results[fn] = df
        print(f'[CLEAN] {fn}: shape={df.shape} saved to {outp}')
    xlsx = os.path.join(data_dir, 'productLabels_multiSpreadsheets.xlsx')
    if os.path.exists(xlsx):
        sheets = pd.read_excel(xlsx, sheet_name=None, dtype=object)
        cleaned = {}
        for sname, df in sheets.items():
            df = clean_df_smart(df, name=sname)
            if 'prod_id' in df.columns:
                df['prod_id'] = df['prod_id'].astype(str)
            df['__sheet__'] = sname
            cleaned[sname] = df
            print(f'[CLEAN] product sheet {sname}: shape={df.shape}')
        prod_df = pd.concat(list(cleaned.values()), ignore_index=True, sort=False)
        outp = os.path.join(cleaned_dir, 'cleaned_productLabels_multiSpreadsheets.xlsx')
        if save:
            with pd.ExcelWriter(outp, engine='openpyxl') as writer:
                for sname, df in cleaned.items():
                    df.to_excel(writer, sheet_name=sname, index=False)
        results['product_xlsx'] = prod_df
        print(f'[CLEAN] product xlsx concatenated shape={prod_df.shape} saved to {outp}')
    else:
        print('[CLEAN] productLabels_multiSpreadsheets.xlsx not found; skipping.')
    return results
