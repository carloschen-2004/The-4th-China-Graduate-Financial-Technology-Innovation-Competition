import os, pandas as pd
import numpy as np

def align_product_features(prod_df, min_numeric_cols=5):
    out = {}
    sheets = prod_df['__sheet__'].unique() if '__sheet__' in prod_df.columns else ['ALL']
    for s in sheets:
        sub = prod_df[prod_df.get('__sheet__','ALL')==s].copy()
        drop_cols = ['prod_id','__sheet__','new_flag']
        cols = [c for c in sub.columns if c not in drop_cols]
        numeric_cols = [c for c in cols if pd.api.types.is_numeric_dtype(sub[c])]
        if len(numeric_cols) < min_numeric_cols:
            candidates = [c for c in cols if c not in numeric_cols]
            for c in candidates:
                try:
                    sub[c+'_cat'] = pd.factorize(sub[c].astype(str))[0]
                    numeric_cols.append(c+'_cat')
                    if len(numeric_cols) >= min_numeric_cols:
                        break
                except Exception:
                    continue
        if len(numeric_cols) == 0:
            sub['prod_hash'] = sub['prod_id'].astype(str).apply(lambda x: abs(hash(x)) % 10000)
            numeric_cols = ['prod_hash']
        for c in numeric_cols:
            sub[c] = pd.to_numeric(sub[c], errors='coerce').fillna(0).astype(float)
        out[s] = {'df': sub, 'numeric_cols': numeric_cols}
    return out

def save_aligned(data_dir, aligned_dict):
    outdir = os.path.join(data_dir, 'aligned')
    os.makedirs(outdir, exist_ok=True)
    for sname, info in aligned_dict.items():
        fname = f'aligned_prod_{sname}.csv'
        info['df'].to_csv(os.path.join(outdir, fname), index=False)
    print(f'[ALIGN] Saved aligned product CSVs to {outdir}')
