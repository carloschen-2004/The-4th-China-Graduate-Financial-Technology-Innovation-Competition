import os, argparse
import pandas as pd, numpy as np
import torch
from sklearn.metrics.pairwise import cosine_similarity
from utils.data_cleaner_v4 import auto_clean_all
from utils.feature_align import align_product_features
from utils.preprocess import preprocess_users_cust_all

def load_model(model_path, embed_dim=64, device='cpu'):
    d = torch.load(model_path, map_location=device)
    from models.user_tower import UserTower
    from models.product_tower import ProductTower
    prod_dim = d.get('prod_dim', None)
    prod_cols = d.get('prod_cols', [])
    user_cols = d.get('user_cols', ['gender','age','edu_bg','marriage_situ_cd'])
    if prod_dim is None or prod_dim==0:
        prod_dim = len(prod_cols) if prod_cols else 1
    user_t = UserTower(len(user_cols), embed_dim)
    prod_t = ProductTower(prod_dim, embed_dim)
    user_t.load_state_dict(d['user_state'])
    prod_t.load_state_dict(d['prod_state'])
    user_t.eval(); prod_t.eval()
    return user_t, prod_t, prod_cols, user_cols

def main(args):
    cust_df, events_df, prod_df = auto_clean_all(args.data_dir)
    cust_df, user_feats = preprocess_users_cust_all(cust_df)
    aligned = align_product_features(prod_df, min_numeric_cols=6)
    user_cols = user_feats
    user_matrix = cust_df[user_cols].fillna(0).astype(float).values
    user_ids = cust_df['cust_no'].astype(str).values
    all_results = []
    cat_store = {}
    for fname in os.listdir(args.model_dir):
        if not fname.startswith('model_') or not fname.endswith('.pth'):
            continue
        cat = fname.split('_')[1].split('.')[0]
        model_path = os.path.join(args.model_dir, fname)
        user_t, prod_t, prod_cols, user_cols_saved = load_model(model_path, embed_dim=args.embed_dim)
        sub = aligned.get(cat)
        if sub is None:
            continue
        prod_sub = sub['df'].reset_index(drop=True)
        prod_cols_use = sub['numeric_cols'] if sub and 'numeric_cols' in sub else prod_cols
        if len(prod_cols_use) == 0:
            prod_sub['prod_hash'] = prod_sub['prod_id'].astype(str).apply(lambda x: abs(hash(x))%10000)
            prod_cols_use = ['prod_hash']
        prod_matrix = prod_sub[prod_cols_use].fillna(0).astype(float).values
        with torch.no_grad():
            user_emb = user_t(torch.tensor(user_matrix, dtype=torch.float32)).numpy()
            prod_emb = prod_t(torch.tensor(prod_matrix, dtype=torch.float32)).numpy()
        from sklearn.preprocessing import normalize
        user_emb = normalize(user_emb, axis=1)
        prod_emb = normalize(prod_emb, axis=1)
        sims = cosine_similarity(prod_emb, user_emb)
        pop = events_df[events_df['event_type'].astype(str).isin(['A','B'])].groupby('prod_id').size().to_dict()
        profiles = []
        for i, pid in enumerate(prod_sub['prod_id']):
            topk_idx = np.argsort(sims[i])[-args.k:][::-1]
            topk_users = user_ids[topk_idx].tolist()
            group = cust_df.iloc[topk_idx]
            profile = {
                'prod_id': pid,
                'category': cat,
                'is_new_product': 0,
                'most_similar_existing_prod_id': '',
                'similarity_score': '',
                'gender_male_ratio': float(group[user_cols].get('gender', group[user_cols][0]).mean()) if 'gender' in user_cols else 0.0,
                'age_mean': float(group[user_cols].get('age', group[user_cols][0]).mean()) if 'age' in user_cols else 0.0,
                'age_median': float(group[user_cols].get('age', group[user_cols][0]).median()) if 'age' in user_cols else 0.0,
                'edu_mode': str(group[user_cols].get('edu_bg', group[user_cols][0]).mode().iloc[0]) if 'edu_bg' in user_cols and not group['edu_bg'].mode().empty else '',
                'marriage_mode': str(group[user_cols].get('marriage_situ_cd', group[user_cols][0]).mode().iloc[0]) if 'marriage_situ_cd' in user_cols and not group['marriage_situ_cd'].mode().empty else '',
                'sample_k': int(len(topk_users)),
                'top_k_custnos': '|'.join(topk_users),
                'popularity': int(pop.get(pid,0))
            }
            profiles.append(profile)
            all_results.append(profile)
        cat_store[cat] = {
            'prod_emb': prod_emb,
            'prod_ids': prod_sub['prod_id'].tolist(),
            'prod_cols': prod_cols_use,
            'profiles_df': pd.DataFrame(profiles),
            'prod_t': prod_t
        }
    for cat, store in cat_store.items():
        sub = aligned.get(cat)
        if sub is None:
            continue
        prod_sub = sub['df'].reset_index(drop=True)
        new_sub = prod_sub[prod_sub.get('new_flag',0)==1].reset_index(drop=True)
        if new_sub.shape[0]==0: continue
        prod_cols_use = store['prod_cols']
        if len(prod_cols_use)==0:
            new_sub['prod_hash'] = new_sub['prod_id'].astype(str).apply(lambda x: abs(hash(x))%10000)
            prod_cols_use = ['prod_hash']
        prod_matrix_new = new_sub[prod_cols_use].fillna(0).astype(float).values
        with torch.no_grad():
            prod_emb_new = store['prod_t'](torch.tensor(prod_matrix_new, dtype=torch.float32)).numpy()
        from sklearn.preprocessing import normalize
        prod_emb_new = normalize(prod_emb_new, axis=1)
        sims = cosine_similarity(prod_emb_new, store['prod_emb'])
        for i, pid in enumerate(new_sub['prod_id']):
            j = int(np.argmax(sims[i])); sim_score = float(sims[i][j])
            old_pid = store['prod_ids'][j]
            ref = store['profiles_df']; row = ref[ref['prod_id']==old_pid]
            if row.shape[0]==0: continue
            r = row.iloc[0].to_dict()
            r.update({'prod_id': pid, 'category': cat, 'is_new_product':1, 'most_similar_existing_prod_id': old_pid, 'similarity_score': sim_score, 'popularity':0})
            all_results.append(r)
    out_df = pd.DataFrame(all_results)
    out_df = out_df.sort_values(['popularity'], ascending=False)
    os.makedirs(os.path.dirname(args.out_csv), exist_ok=True)
    out_df.to_csv(args.out_csv, index=False)
    print(f'[RESULT] Saved recommendations to {args.out_csv}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', default='data')
    parser.add_argument('--model_dir', default='outputs')
    parser.add_argument('--out_csv', default='outputs/recommended_user_profiles.csv')
    parser.add_argument('--k', type=int, default=200)
    parser.add_argument('--embed_dim', type=int, default=64)
    args = parser.parse_args()
    main(args)
