import os, pandas as pd, numpy as np
import re

def normalize_id_str(s):
    # convert to string, strip whitespace, remove trailing .0 for numeric-looking ids, lower-case
    if s is None:
        return ''
    s = str(s).strip()
    # remove trailing .0 (common when numeric saved as float)
    if re.match(r'^\d+\.0$', s):
        s = s.rsplit('.0',1)[0]
    # remove scientific notation artifacts like 1.234e+03 -> int if possible
    try:
        if 'e' in s.lower():
            v = float(s)
            if abs(v - int(v)) < 1e-6:
                s = str(int(v))
    except:
        pass
    # final strip and lower
    s = s.strip()
    return s


# Auto-detect id column names mapping
CUST_ID_CANDIDATES = ['cust_no','customer_id','custid','客户号','CUST_ID']
PROD_ID_CANDIDATES = ['prod_id','product_id','prod_code','产品编号','PROD_ID','PROD_CD']
EVENT_TYPE_CANDIDATES = ['event_type','trans_type','event_cd','事件类型','交易类型']

def find_first_column(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
        for col in df.columns:
            if str(col).lower() == c.lower():
                return col
    for col in df.columns:
        low = str(col).lower()
        for c in candidates:
            if c.lower() in low:
                return col
    return None

def clean_cust_df(path):
    df = pd.read_csv(path, dtype=object)
    id_col = find_first_column(df, CUST_ID_CANDIDATES)
    if id_col is None:
        raise ValueError('cust id column not found in cust dataset')
    df.rename(columns={id_col: 'cust_no'}, inplace=True)
    for col in df.columns:
        if col == 'cust_no':
            df['cust_no'] = df['cust_no'].astype(str)
            continue
        df[col] = pd.to_numeric(df[col], errors='coerce')
        df[col] = df[col].fillna(0)
    cols = ['cust_no'] + [c for c in df.columns if c != 'cust_no']
    df = df[cols]
    return df

def clean_event_df(path):
    df = pd.read_csv(path, dtype=object)
    prod_col = find_first_column(df, PROD_ID_CANDIDATES)
    cust_col = find_first_column(df, CUST_ID_CANDIDATES)
    event_col = find_first_column(df, EVENT_TYPE_CANDIDATES)
    if prod_col is None:
        raise ValueError('prod id column not found in event dataset')
    if cust_col is None:
        raise ValueError('cust id column not found in event dataset')
    if event_col is None:
        raise ValueError('event type column not found in event dataset')
    df.rename(columns={prod_col:'prod_id', cust_col:'cust_no', event_col:'event_type'}, inplace=True)
    df['prod_id'] = df['prod_id'].astype(str)
    df['cust_no'] = df['cust_no'].astype(str)
    df['event_type'] = df['event_type'].astype(str).str.strip()
    for col in df.columns:
        if col in ['prod_id','cust_no','event_type']:
            continue
        df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
    return df

def clean_product_xlsx(path):
    sheets = pd.read_excel(path, sheet_name=None, dtype=object)
    cleaned = []
    for sname, df in sheets.items():
        if 'prod_id' not in df.columns:
            for c in ['prod_id','product_id','prod_code','PROD_ID','PROD_CD']:
                if c in df.columns:
                    df.rename(columns={c:'prod_id'}, inplace=True)
                    break
        if 'prod_id' not in df.columns:
            raise ValueError(f'prod_id not found in sheet {sname}')
        df['prod_id'] = df['prod_id'].astype(str)
        df['__sheet__'] = sname
        for col in df.columns:
            if col in ['prod_id','__sheet__']:
                continue
            try:
                df[col] = pd.to_numeric(df[col], errors='coerce')
                df[col] = df[col].fillna(0)
            except:
                df[col] = df[col].fillna(0).astype(str)
                try:
                    if df[col].nunique() < 200:
                        df[col] = pd.factorize(df[col].astype(str))[0]
                except:
                    pass
        cleaned.append(df)
    prod_df = pd.concat(cleaned, ignore_index=True, sort=False)
    return prod_df

def auto_clean_all(data_dir):
    cleaned_dir = os.path.join(data_dir, 'cleaned')
    os.makedirs(cleaned_dir, exist_ok=True)
    cust_path = os.path.join(data_dir, 'cust_dataset.csv')
    event_path = os.path.join(data_dir, 'event_dataset.csv')
    prod_path = os.path.join(data_dir, 'productLabels_multiSpreadsheets.xlsx')
    cust_df = clean_cust_df(cust_path)
    event_df = clean_event_df(event_path)
    prod_df = clean_product_xlsx(prod_path)
    cust_df.to_csv(os.path.join(cleaned_dir, 'cleaned_cust_dataset.csv'), index=False)
    event_df.to_csv(os.path.join(cleaned_dir, 'cleaned_event_dataset.csv'), index=False)
    prod_df.to_excel(os.path.join(cleaned_dir, 'cleaned_productLabels_multiSpreadsheets.xlsx'), index=False)
    return cust_df, event_df, prod_df
