import pandas as pd, numpy as np
from datetime import datetime

def preprocess_users_cust_all(cust_df):
    df = cust_df.copy()
    if 'cust_no' not in df.columns:
        raise ValueError('cust_no not found in cust df')
    feat_cols = [c for c in df.columns if c != 'cust_no']
    for c in feat_cols:
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0).astype(float)
    if 'birth_ym' in df.columns:
        def extract_year(x):
            try:
                s=str(int(x))
                return int(s[:4])
            except:
                return 0
        df['birth_year'] = df['birth_ym'].apply(extract_year).fillna(0).astype(int)
    else:
        df['birth_year'] = 0
    df['age'] = datetime.now().year - df['birth_year']
    if 'age' not in feat_cols:
        df['age'] = df['age'].fillna(df['age'].median()).astype(float)
    if 'gender' not in df.columns:
        df['gender'] = 0.0
    df['gender'] = pd.to_numeric(df['gender'], errors='coerce').fillna(0).astype(float)
    final_feats = [c for c in df.columns if c != 'cust_no']
    nz = df[final_feats].std().replace(0, float('nan')).dropna().index.tolist()
    df = df[['cust_no'] + nz]
    return df, nz
