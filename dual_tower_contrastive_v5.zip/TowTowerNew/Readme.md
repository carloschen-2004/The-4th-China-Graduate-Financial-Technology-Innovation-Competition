**在v4f7的基础上修改：**

1. user\_cols加入历史行为：'prev count C’,'prev count D’,'prev count N',"prev count p' 'prev count A'，表示在此日期之前，有过几次被推荐某类产品的事件
2. 增加了真正的硬负样本的惩罚项
3. --use\_hard\_negative 默认值改为了True
4. --epochs 默认值改为了3



**直接运行train\_per\_category.py就行**

